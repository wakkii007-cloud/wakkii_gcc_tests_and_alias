


void Swap(int* x, int* y);

void xy_show(int x,int y);

void x1y1_show(int x1,int y1);






