
#include "Swap.h"

void Swap(int* x, int* y)
{
		int x_save = *x;
		*x = *y;
		*y = x_save;

}



