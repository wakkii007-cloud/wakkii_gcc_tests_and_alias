

#include <stdio.h>

void Swap(int* x, int* y)
{
		int x_save = *x;
		*x = *y;
		*y = x_save;

}




//#include <stdio.h>

void xy_show(int x, int y)
{
		 printf("(x=%d,y=%d)xyを表示します。\n",x,y);
		//return 0;
}





//#include <stdio.h>

void x1y1_show(int x1, int y1)
{
		 printf("(x1=%d,y1=%d)x1y1を表示します。\n",x1,y1);
		//return 0;
}




//#include "Swap.h"
//#include "Show.h"
//#include <stdio.h>

//extern void Swap(*x,*y);
//extern void xy_show(x,y);

extern int main(int argc,char** argv)
{

		int x1 = 5;
		int y1 = 10;
		int *x;
		x = &x1;
		int *y;
		y = &y1;

		char words1[] = "begin a program";
		char words2[] = "swap execute";
		char words3[] = "finish a program";
		char *p;

		p = words1;
	    	printf("Hello World!\n%s\n",p); 
	    	p = words2;

		//ポインタ渡しのスワップ
		
		xy_show(*x, *y);
		printf("%s\n",p);	
		Swap(x, y);
		xy_show(*x, *y);
		printf("%s\n",p);	
		Swap(x, y);
		xy_show(*x, *y);
		printf("%s\n",p);	
		Swap(x, y);
		xy_show(*x, *y);

		//参照渡しのスワップ

		x1 = 2;
		y1 = 4;
	
		x1y1_show(x1,y1);
		printf("%s\n",p);	
		Swap(&x1, &y1);
		x1y1_show(x1, y1);
		printf("%s\n",p);	
		Swap(&x1, &y1);
		x1y1_show(x1, y1);
		printf("%s\n",p);	
		Swap(&x1, &y1);
		x1y1_show(x1, y1);

																	//ポインタの確認。
		printf("\nポインタ World!\n\n");
		xy_show(*x, *y);
																				
		p = words3;
		printf("%s\n",p);	
	

}


