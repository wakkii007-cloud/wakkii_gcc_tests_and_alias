#include "Show.h"
#include <stdio.h>

//extern void Swap(int* x,int* y);
//extern void xy_show(int x,int y);
//extern void x1y1_show(int x1,int y1);

extern int main(int argc,char** argv)
{

		int x1 = 5;
		int y1 = 10;
		int *x;
		x = &x1;
		int *y;
		y = &y1;

		char words1[] = "begin a program";
		char words2[] = "swap execute";
		char words3[] = "finish a program";
		char *p;

		p = words1;
	    	printf("Hello World!\n%s\n",p); 
	    	p = words2;

		//ポインタ渡しのスワップ
		
		xy_show(*x, *y);
		printf("%s\n",p);	
		Swap(x, y);
		xy_show(*x, *y);
		printf("%s\n",p);	
		Swap(x, y);
		xy_show(*x, *y);
		printf("%s\n",p);	
		Swap(x, y);
		xy_show(*x, *y);

		//参照渡しのスワップ

		x1 = 2;
		y1 = 4;
	
		x1y1_show(x1,y1);
		printf("%s\n",p);	
		Swap(&x1, &y1);
		x1y1_show(x1, y1);
		printf("%s\n",p);	
		Swap(&x1, &y1);
		x1y1_show(x1, y1);
		printf("%s\n",p);	
		Swap(&x1, &y1);
		x1y1_show(x1, y1);

																	//ポインタの確認。
		printf("\nポインタ World!\n\n");
		xy_show(*x, *y);
																				
		p = words3;
		printf("%s\n",p);	
	

}


