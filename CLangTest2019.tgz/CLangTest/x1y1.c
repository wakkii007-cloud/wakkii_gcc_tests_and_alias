
#include "x1y1.h"

void x1y1_show(int x1, int y1)
{
		 printf("(x1=%d,y1=%d)x1y1を表示します。\n",x1,y1);
		//return 0;
}




