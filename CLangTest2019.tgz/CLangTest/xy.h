

#include <stdio.h>

void xy_show(int x, int y);




