
#include <stdio.h>
#include "x1y1.h"

void px1y1(int x1, int y1)
{
		 x1y1_show(x1,y1);
		//return 0;
}




