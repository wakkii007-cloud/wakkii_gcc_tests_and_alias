


#include "x1y10.h"


void px1y1(int x, int y);




