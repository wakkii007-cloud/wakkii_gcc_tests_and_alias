


void x1y1_show(int x1, int y1);




