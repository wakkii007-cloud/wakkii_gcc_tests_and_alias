
#include <stdio.h>
#include "xy.h"


void pxy(int x, int y)
{
		 xy_show(x,y);
		//return 0;
}




