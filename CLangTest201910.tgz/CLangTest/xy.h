



#include "xy0.h"

void pxy(int x,int y);


