
#include <stdio.h>
#include "xy0.h"


void xy_show(int x, int y)
{
		 printf("(x=%d,y=%d)xyを表示します。\n",x,y);
		//return 0;
}




