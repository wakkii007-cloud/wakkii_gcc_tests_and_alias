


void xy_show(int x, int y);




