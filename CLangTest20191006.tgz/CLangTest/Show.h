

#include "Swap.h"
//void Swap(int* x, int* y);
#include "xy.h"
//void xy_show(int x,int y);
//void pxy(int x, int y);
#include "x1y1.h"
//void x1y1_show(int x1,int y1);
//void px1y1(int x1, int y1);





